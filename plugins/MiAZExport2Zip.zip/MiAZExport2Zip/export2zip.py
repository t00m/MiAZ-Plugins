#!/usr/bin/python3
# pylint: disable=E1101

"""
# File: export2zip.py
# Author: Tomás Vírseda
# License: GPL v3
# Description: Plugin for exporting documents to ZIP
"""

import os
import shutil
from gettext import gettext as _

from gi.repository import GObject
from gi.repository import Gtk
from gi.repository import Peas

from MiAZ.frontend.desktop.services.pluginsystem import MiAZPlugin
from MiAZ.backend.models import Country, Date, Group
from MiAZ.backend.models import Purpose, SentBy, SentTo

Field = {}
Field[Date] = 0
Field[Country] = 1
Field[Group] = 2
Field[SentBy] = 3
Field[Purpose] = 4
Field[SentTo] = 6


class Export2Zip(GObject.GObject, Peas.Activatable):
    __gtype_name__ = 'MiAZExport2ZipPlugin'
    object = GObject.Property(type=GObject.Object)
    plugin = None
    file = __file__.replace('.py', '.plugin')

    def do_activate(self):
        """Plugin activation"""
        # Setup plugin
        ## Get pointer to app
        self.app = self.object.app
        self.plugin = MiAZPlugin(self.app)

        ## Initialize plugin
        self.plugin.register(self.file, self)

        ## Get logger
        self.log = self.plugin.get_logger()

        # Connect startup signals
        self.workspace = self.app.get_widget('workspace')
        self.workspace.connect('workspace-loaded', self.startup)

        # Get services
        self.actions = self.app.get_service('actions')
        self.factory = self.app.get_service('factory')
        self.repository = self.app.get_service('repo')
        self.util = self.app.get_service('util')
        self.srvdlg = self.app.get_service('dialogs')

    def do_deactivate(self):
        self.log.warning("Deactivation not implemented")

    def startup(self, *args):
        if not self.plugin.menu_item_loaded():
            # Create menu item for plugin
            menuitem = self.plugin.get_menu_item(callback=self.export)

            # Add plugin to its default (sub)category
            self.plugin.install_menu_entry(menuitem)


    def export(self, *args):
        self.items = self.workspace.get_selected_items()
        if self.actions.stop_if_no_items(self.items):
            return
        self.target_dir = None
        self.factory.create_filechooser_for_directories(self._on_select_folder_response)

    def _on_select_folder_response(self, dialog, result):
        try:
            folder = dialog.select_folder_finish(result)
            self.target_dir = folder.get_path()
            target_dir_valid = os.path.exists(self.target_dir)
            if self.target_dir is not None and target_dir_valid:
                ENV = self.app.get_env()
                dir_zip = self.util.get_temp_dir()
                self.util.directory_create(dir_zip)
                for item in self.items:
                    source = os.path.join(self.repository.docs, item.id)
                    target = dir_zip
                    self.util.filename_copy(source, target)
                basename = os.path.basename(dir_zip)
                zip_file = f"{basename}.zip"
                zip_target = os.path.join(ENV['LPATH']['TMP'], zip_file)
                source = zip_target
                target = os.path.join(self.target_dir, zip_file)
                self.util.zip(target, dir_zip)
                self.util.filename_rename(source, target)
                shutil.rmtree(dir_zip)
                self.util.directory_open(self.target_dir)

                body = f"<big>Check your default file browser</big>"
                window = self.workspace.get_root()
                body=''
                self.srvdlg.create(dtype='info', title=_('Export successfull'), body=body).present(window)

        except Exception as error:
            self.srvdlg.show_error(title='Export error', body=error)
            self.log.error(f"Error selecting files: {error}")

